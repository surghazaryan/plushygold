from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
from modules.rag_engine import retrieve_context
from modules.llm_engine import generate_answer

app = FastAPI(title="VIREL AGI Backend")

# --- Разрешим запросы от фронта ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # при деплое укажи домен
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Модель запроса от клиента ---
class Query(BaseModel):
    query: str

@app.post("/ask")
async def ask_virel(data: Query):
    """Главная точка общения VIREL"""
    question = data.query.strip()
    if not question:
        return {"reply": "Пожалуйста, сформулируйте вопрос."}

    # 1️⃣ Получаем релевантные фрагменты из меморандума
    context = retrieve_context(question)

    # 2️⃣ Генерируем ответ
    reply = generate_answer(question, context)

    return {"reply": reply}

@app.get("/")
def home():
    return {"VIREL": "AGI Alliance Group backend operational ✅"}
