import chromadb
from chromadb.utils import embedding_functions
import os

# Инициализация Chroma
client = chromadb.Client()
collection = client.get_or_create_collection("virel_memorandum")

# Используем встроенный эмбеддер OpenAI (или HuggingFace)
openai_ef = embedding_functions.OpenAIEmbeddingFunction(api_key=os.getenv("OPENAI_API_KEY"), model_name="text-embedding-3-small")

# --- Предзагрузка данных (один раз при старте) ---
def load_memorandum():
    with open("data/virel_memorandum.txt", "r", encoding="utf-8") as f:
        text = f.read()
    chunks = split_text(text)
    for i, chunk in enumerate(chunks):
        collection.add(documents=[chunk], ids=[str(i)])
    print(f"✅ Загружено {len(chunks)} сегментов меморандума")

def split_text(text, max_len=800):
    words = text.split()
    chunks, current = [], []
    for w in words:
        current.append(w)
        if len(current) >= max_len:
            chunks.append(" ".join(current))
            current = []
    if current:
        chunks.append(" ".join(current))
    return chunks

# --- Получение контекста ---
def retrieve_context(query: str, n_results: int = 3):
    results = collection.query(query_texts=[query], n_results=n_results)
    docs = results["documents"][0]
    return "\n\n".join(docs)

# При запуске — прогружаем документ
try:
    load_memorandum()
except Exception as e:
    print("⚠️ Не удалось загрузить меморандум:", e)
