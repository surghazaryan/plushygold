from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

SYSTEM_PROMPT = """Ты — VIREL, виртуальная представительница проекта AGI Alliance Group.
Отвечай вежливо, уверенно и ссылайся на меморандум, если ответ основан на его содержании.
Если информации недостаточно — говори честно. Не придумывай факты.
"""

def generate_answer(query: str, context: str):
    prompt = f"{SYSTEM_PROMPT}\n\nКонтекст:\n{context}\n\nВопрос: {query}\nОтвет:"
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # можно заменить на нужный
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"{query}\n\nКонтекст:\n{context}"}
            ],
            temperature=0.6,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print("Ошибка LLM:", e)
        return "Извините, возникла ошибка при генерации ответа."
